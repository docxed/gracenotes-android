วิธีติดตั้ง
1. แตกไฟล์ gracenotes-android
2. เข้าไปที่ gracenotes-android\db
3. นำไฟล์ .sql ไป import ตั้งชื่อ Table ว่า "gracenote_android" ด้วยโปรแกรม MySQL ตัวใดก็ได้เช่น xampp
4. เข้าไปที่ gracenotes-android\backend
5. ทำการติดตั้ง package เพียงแค่พิมพ์คำสั่งบน cmd ว่า "npm install"
6. ทำการเปิดฝั่ง server โดยพิมพ์คำสั่งบน cmd ว่า "npm run dev"
7. เข้าไปที่ gracenotes-android\frontend
8. ทำการติดตั้ง package เพียงแค่พิมพ์คำสั่งบน cmd ว่า "yarn"
9. ทำการเปิดฝั่ง client เพียงแค่พิมพ์คำสั่งบน cmd ว่า "expo start"
10. แล้วเลือก Run on Android device/emulator เท่านั้น

หมายเหตุ
- บัญชี student
user: 62070168
pass: 1234
- บัญชี teacher
user: 62070215
pass: 1234

วิดีโอสาธิตการติดตั้ง
- https://youtu.be/qSjSMOchTjA
วิดีโอการนำเสนอ
- https://youtu.be/huxr2teUkvM