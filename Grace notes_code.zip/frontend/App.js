import * as React from "react"
import MyNavigator from "./Navigation/Navigator";

export default () => {
  return <MyNavigator/>;
}
