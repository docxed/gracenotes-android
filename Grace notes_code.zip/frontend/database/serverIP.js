export const SERVER_IP = "10.0.2.2"
export const PORT = "5001"

// 192.168.1.34
// 10.0.2.2